package com.javaex.problem04;

public abstract class Bird {
    private String name;



}
